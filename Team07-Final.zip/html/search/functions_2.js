var searchData=
[
  ['deletegroup',['deleteGroup',['../class_group_container.html#a6b2ae4e765c8a6febae640bc6b54a918',1,'GroupContainer']]],
  ['deleteschedule',['deleteSchedule',['../class_schedule_container.html#ac33b6dd63edc6170ceec240c4f144de7',1,'ScheduleContainer']]]
];
